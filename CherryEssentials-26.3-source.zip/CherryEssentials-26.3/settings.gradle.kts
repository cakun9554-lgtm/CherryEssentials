rootProject.name = "CherryEssentials"
