package id.berry.essentials;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.*;
import org.bukkit.util.Vector;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public final class CherryEssentials extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {
    private File dataFile;
    private YamlConfiguration data;
    private final Map<UUID, UUID> tpaRequests = new HashMap<>();
    private final Map<UUID, Long> kills = new HashMap<>(), deaths = new HashMap<>();
    private final Map<UUID, String> openViews = new HashMap<>();
    private BukkitTask boardTask;
    private static final String SHOP_TITLE = "§5Cherry§6 Shop";
    private static final String MENU_TITLE = "§5Cherry§6 Member Menu";
    private static final String BACKPACK_TITLE = "§5Cherry§6 Backpack";

    @Override public void onEnable() {
        saveDefaultConfig();
        if (!getDataFolder().exists()) getDataFolder().mkdirs();
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        for (String c : List.of("cherry","money","pay","bank","sethome","home","delhome","setwarp","warp","delwarp","tpa","tpaccept","rtp","shop","backpack","clan","rank","menu","quest")) {
            PluginCommand command = getCommand(c);
            if (command != null) { command.setExecutor(this); command.setTabCompleter(this); }
        }
        getServer().getPluginManager().registerEvents(this, this);
        boardTask = Bukkit.getScheduler().runTaskTimer(this, () -> Bukkit.getOnlinePlayers().forEach(this::updateBoard), 20L, 40L);
        getLogger().info("CherryEssentials enabled. Paper API target: 26.3; author: CherryEssentials.");
    }

    @Override public void onDisable() { if (boardTask != null) boardTask.cancel(); saveData(); }
    private void saveData() { try { data.save(dataFile); } catch (IOException e) { getLogger().severe("Could not save data.yml: " + e.getMessage()); } }
    private String prefix() { return color(getConfig().getString("settings.prefix", "&8[&5Cherry&6Essentials&8] &r")); }
    private static String color(String s) { return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s); }
    private void msg(CommandSender s, String m) { s.sendMessage(prefix() + color(m)); }
    private boolean playerOnly(CommandSender s) { if (s instanceof Player) return false; msg(s, "&cThis command can only be used in-game."); return true; }
    private String path(Player p) { return "players." + p.getUniqueId(); }
    private double balance(UUID id) { return data.getDouble("players." + id + ".money", getConfig().getDouble("settings.economy.starting-balance", 1000)); }
    private double bank(UUID id) { return data.getDouble("players." + id + ".bank", 0); }
    private void setBalance(UUID id, double v) { data.set("players." + id + ".money", Math.max(0, v)); saveData(); }
    private void setBank(UUID id, double v) { data.set("players." + id + ".bank", Math.max(0, v)); saveData(); }
    private String money(double v) { return getConfig().getString("settings.economy.currency-symbol", "$") + String.format(Locale.US, "%,.2f", v); }
    private boolean validAmount(String s) { try { return Double.isFinite(Double.parseDouble(s)) && Double.parseDouble(s) > 0; } catch (Exception e) { return false; } }
    private Player findPlayer(String name) { Player p = Bukkit.getPlayerExact(name); if (p != null) return p; for (Player online : Bukkit.getOnlinePlayers()) if (online.getName().equalsIgnoreCase(name)) return online; return null; }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] a) {
        String c = command.getName().toLowerCase(Locale.ROOT);
        if (c.equals("money")) { if (playerOnly(sender)) return true; Player p=(Player)sender; msg(p,"&fBalance: &e"+money(balance(p.getUniqueId()))+" &7| Bank: &e"+money(bank(p.getUniqueId()))); return true; }
        if (c.equals("pay")) { if (playerOnly(sender)) return true; if(a.length!=2 || !validAmount(a[1])) {msg(sender,"&cUsage: /pay <player> <amount>");return true;} Player from=(Player)sender,to=findPlayer(a[0]); double n=Double.parseDouble(a[1]); if(to==null){msg(sender,"&cPlayer must be online.");return true;} if(to.equals(from)||balance(from.getUniqueId())<n){msg(sender,"&cInvalid recipient or insufficient funds.");return true;} setBalance(from.getUniqueId(),balance(from.getUniqueId())-n);setBalance(to.getUniqueId(),balance(to.getUniqueId())+n);msg(from,"&aSent "+money(n)+" to "+to.getName()+".");msg(to,"&aReceived "+money(n)+" from "+from.getName()+".");return true; }
        if (c.equals("bank")) { if(playerOnly(sender))return true; if(a.length!=2||!validAmount(a[1])||!(a[0].equalsIgnoreCase("deposit")||a[0].equalsIgnoreCase("withdraw"))){msg(sender,"&cUsage: /bank <deposit|withdraw> <amount>");return true;} Player p=(Player)sender;double n=Double.parseDouble(a[1]);if(a[0].equalsIgnoreCase("deposit")){if(balance(p.getUniqueId())<n){msg(p,"&cNot enough money.");return true;}setBalance(p.getUniqueId(),balance(p.getUniqueId())-n);setBank(p.getUniqueId(),bank(p.getUniqueId())+n);}else{if(bank(p.getUniqueId())<n){msg(p,"&cNot enough bank funds.");return true;}setBank(p.getUniqueId(),bank(p.getUniqueId())-n);setBalance(p.getUniqueId(),balance(p.getUniqueId())+n);}msg(p,"&aTransaction complete. Balance: "+money(balance(p.getUniqueId()))+" | Bank: "+money(bank(p.getUniqueId())));return true; }
        if (c.equals("sethome")) {if(playerOnly(sender))return true;Player p=(Player)sender;String n=a.length>0?a[0].toLowerCase(Locale.ROOT):"home";String base=path(p)+".homes";if(!data.contains(base+"."+n)&&data.getConfigurationSection(base)==null&&getConfig().getInt("settings.homes.default-limit",3)<=0){msg(p,"&cHome limit reached.");return true;}if(data.getConfigurationSection(base)!=null&&data.getConfigurationSection(base).getKeys(false).size()>=getConfig().getInt("settings.homes.default-limit",3)&&!data.contains(base+"."+n)){msg(p,"&cHome limit reached.");return true;}saveLocation(base+"."+n,p.getLocation());msg(p,"&aHome '&e"+n+"&a' saved.");return true;}
        if (c.equals("home")) {if(playerOnly(sender))return true;Player p=(Player)sender;String n=a.length>0?a[0].toLowerCase(Locale.ROOT):"home";Location l=readLocation(path(p)+".homes."+n);if(l==null){msg(p,"&cHome not found.");return true;}p.teleportAsync(l);msg(p,"&aTeleporting home '&e"+n+"&a'.");return true;}
        if (c.equals("delhome")) {if(playerOnly(sender))return true;Player p=(Player)sender;String n=a.length>0?a[0].toLowerCase(Locale.ROOT):"home";data.set(path(p)+".homes."+n,null);saveData();msg(p,"&aHome deleted.");return true;}
        if (c.equals("setwarp")) {if(!sender.hasPermission("cherry.admin")){msg(sender,"&cNo permission.");return true;}if(playerOnly(sender)||a.length<1)return true;saveLocation("warps."+a[0].toLowerCase(Locale.ROOT),((Player)sender).getLocation());msg(sender,"&aWarp saved.");return true;}
        if (c.equals("warp")) {if(playerOnly(sender))return true;if(a.length<1){msg(sender,"&eWarps: "+String.join(", ",data.getConfigurationSection("warps")==null?Set.of():data.getConfigurationSection("warps").getKeys(false)));return true;}Location l=readLocation("warps."+a[0].toLowerCase(Locale.ROOT));if(l==null){msg(sender,"&cWarp not found.");return true;}((Player)sender).teleportAsync(l);msg(sender,"&aTeleporting...");return true;}
        if (c.equals("delwarp")) {if(!sender.hasPermission("cherry.admin")){msg(sender,"&cNo permission.");return true;}if(a.length>0){data.set("warps."+a[0].toLowerCase(Locale.ROOT),null);saveData();msg(sender,"&aWarp deleted.");}return true;}
        if (c.equals("tpa")) {if(playerOnly(sender))return true;if(a.length!=1){msg(sender,"&cUsage: /tpa <player>");return true;}Player p=(Player)sender,to=findPlayer(a[0]);if(to==null||to.equals(p)){msg(p,"&cPlayer not found.");return true;}tpaRequests.put(to.getUniqueId(),p.getUniqueId());msg(p,"&aTeleport request sent to "+to.getName()+".");msg(to,"&e"+p.getName()+" wants to teleport. Use /tpaccept.");long wait=getConfig().getLong("settings.tpa-expire-seconds",60);Bukkit.getScheduler().runTaskLater(this,()->tpaRequests.remove(to.getUniqueId(),p.getUniqueId()),wait*20);return true;}
        if (c.equals("tpaccept")) {if(playerOnly(sender))return true;Player to=(Player)sender;UUID id=tpaRequests.remove(to.getUniqueId());Player from=id==null?null:Bukkit.getPlayer(id);if(from==null){msg(to,"&cNo pending request.");return true;}from.teleportAsync(to.getLocation());msg(from,"&aTeleport request accepted.");msg(to,"&aRequest accepted.");return true;}
        if (c.equals("rtp")) {if(playerOnly(sender))return true;Player p=(Player)sender;int min=getConfig().getInt("settings.rtp.min-radius",500),max=getConfig().getInt("settings.rtp.max-radius",5000);for(int i=0;i<getConfig().getInt("settings.rtp.max-attempts",30);i++){double angle=ThreadLocalRandom.current().nextDouble(0,Math.PI*2),r=ThreadLocalRandom.current().nextDouble(min,max);int x=p.getLocation().getBlockX()+(int)(Math.cos(angle)*r),z=p.getLocation().getBlockZ()+(int)(Math.sin(angle)*r);World w=p.getWorld();int y=w.getHighestBlockYAt(x,z);Location l=new Location(w,x+0.5,y+1,z+0.5);if(w.getBlockAt(x,y,z).getType().isSolid()&&!w.getBlockAt(x,y+1,z).getType().isSolid()&&!w.getBlockAt(x,y+2,z).getType().isSolid()){p.teleportAsync(l);msg(p,"&aRandom teleporting...");return true;}}msg(p,"&cSafe location not found. Try again.");return true;}
        if (c.equals("shop")) {if(playerOnly(sender))return true;openShop((Player)sender);return true;}
        if (c.equals("backpack")) {if(playerOnly(sender))return true;Player p=(Player)sender;Inventory inv=Bukkit.createInventory(p,54,BACKPACK_TITLE);ItemStack[] stored=data.getObject(path(p)+".backpack") instanceof ItemStack[] arr?arr:null;if(stored!=null)inv.setContents(stored);openViews.put(p.getUniqueId(),"backpack");p.openInventory(inv);return true;}
        if (c.equals("menu")||c.equals("cherry")) {if(playerOnly(sender))return true;openMenu((Player)sender);return true;}
        if (c.equals("rank")) {if(!sender.hasPermission("cherry.admin")){msg(sender,"&cNo permission.");return true;}if(a.length<2){msg(sender,"&cUsage: /rank <player> <rank>");return true;}Player target=findPlayer(a[0]);if(target==null){msg(sender,"&cPlayer must be online.");return true;}data.set(path(target)+".rank",a[1]);saveData();updateBoard(target);msg(sender,"&aRank updated for "+target.getName()+".");msg(target,"&aYour rank is now "+a[1]+".");return true;}
        if (c.equals("clan")) {if(playerOnly(sender))return true;Player p=(Player)sender;if(a.length==0){msg(p,"&eClan: "+data.getString(path(p)+".clan","None")+" &7| /clan create <name> | /clan leave");return true;}if(a[0].equalsIgnoreCase("create")&&a.length>1){String key=a[1].toLowerCase(Locale.ROOT);if(data.contains("clans."+key)){msg(p,"&cClan already exists.");return true;}data.set("clans."+key+".name",a[1]);data.set("clans."+key+".leader",p.getUniqueId().toString());data.set(path(p)+".clan",a[1]);saveData();msg(p,"&aClan created: "+a[1]);return true;}if(a[0].equalsIgnoreCase("leave")){data.set(path(p)+".clan",null);saveData();msg(p,"&aYou left your clan.");return true;}msg(p,"&cUnknown clan action.");return true;}
        if (c.equals("quest")) {if(playerOnly(sender))return true;Player p=(Player)sender;int kills=(int)data.getLong(path(p)+".quest.kills",0);msg(p,"&6Daily Quest: &fDefeat 5 mobs &7("+Math.min(kills,5)+"/5)");if(kills>=5)msg(p,"&aQuest complete! (Quest rewards are configurable in a future module.)");return true;}
        return false;
    }

    private void saveLocation(String path, Location l){data.set(path+".world",l.getWorld().getName());data.set(path+".x",l.getX());data.set(path+".y",l.getY());data.set(path+".z",l.getZ());data.set(path+".yaw",l.getYaw());data.set(path+".pitch",l.getPitch());saveData();}
    private Location readLocation(String path){String wn=data.getString(path+".world");World w=wn==null?null:Bukkit.getWorld(wn);if(w==null||!data.contains(path+".x"))return null;return new Location(w,data.getDouble(path+".x"),data.getDouble(path+".y"),data.getDouble(path+".z"),(float)data.getDouble(path+".yaw"),(float)data.getDouble(path+".pitch"));}
    private void openShop(Player p){Inventory inv=Bukkit.createInventory(p,27,SHOP_TITLE);ConfigurationSection sec=getConfig().getConfigurationSection("settings.shop.items");if(sec!=null)for(String key:sec.getKeys(false)){String mat=sec.getString(key+".material","STONE");Material m=Material.matchMaterial(mat);if(m==null)continue;ItemStack item=new ItemStack(m,Math.max(1,sec.getInt(key+".amount",1)));ItemMeta meta=item.getItemMeta();double price=sec.getDouble(key+".price",0);meta.displayName(Component.text(m.name().replace('_',' '),NamedTextColor.YELLOW));meta.lore(List.of(Component.text("Price: "+money(price),NamedTextColor.GOLD),Component.text("Click to purchase",NamedTextColor.GRAY)));item.setItemMeta(meta);int slot=sec.getInt(key+".slot",10);if(slot>=0&&slot<27)inv.setItem(slot,item);}openViews.put(p.getUniqueId(),"shop");p.openInventory(inv);}
    private void openMenu(Player p){Inventory inv=Bukkit.createInventory(p,27,MENU_TITLE);put(inv,11,Material.EMERALD,"§aEconomy", "§7Your balance and bank");put(inv,13,Material.CHEST,"§6Backpack", "§7Open personal storage");put(inv,15,Material.GOLD_INGOT,"§eShop", "§7Browse server shop");put(inv,22,Material.BOOK,"§dQuests", "§7View your quests");openViews.put(p.getUniqueId(),"menu");p.openInventory(inv);}
    private void put(Inventory inv,int slot,Material m,String name,String lore){ItemStack it=new ItemStack(m);ItemMeta meta=it.getItemMeta();meta.displayName(Component.text(name));meta.lore(List.of(Component.text(lore)));it.setItemMeta(meta);inv.setItem(slot,it);}
    @EventHandler public void onInventoryClick(InventoryClickEvent e){if(!(e.getWhoClicked() instanceof Player p))return;String view=openViews.get(p.getUniqueId());if(view==null)return;if(e.getView().getTopInventory()!=e.getClickedInventory()&&e.getClickedInventory()!=null)return;e.setCancelled(true);if(e.getClickedInventory()==null)return;int slot=e.getRawSlot();if(view.equals("menu")){if(slot==11)msg(p,"&fBalance: &e"+money(balance(p.getUniqueId()))+" &7| Bank: &e"+money(bank(p.getUniqueId())));if(slot==13)p.performCommand("backpack");if(slot==15)openShop(p);if(slot==22)p.performCommand("quest");}else if(view.equals("shop")){ConfigurationSection sec=getConfig().getConfigurationSection("settings.shop.items");if(sec==null)return;for(String key:sec.getKeys(false)){if(sec.getInt(key+".slot")==slot){Material m=Material.matchMaterial(sec.getString(key+".material","STONE"));int amount=sec.getInt(key+".amount",1);double price=sec.getDouble(key+".price",0);if(m==null)return;if(balance(p.getUniqueId())<price){msg(p,"&cNot enough money.");return;}if(p.getInventory().firstEmpty()==-1){msg(p,"&cYour inventory is full.");return;}setBalance(p.getUniqueId(),balance(p.getUniqueId())-price);p.getInventory().addItem(new ItemStack(m,amount));msg(p,"&aPurchased "+amount+"x "+m.name()+" for "+money(price)+".");return;}}}}
    @EventHandler public void onClose(org.bukkit.event.inventory.InventoryCloseEvent e){if(!(e.getPlayer() instanceof Player p))return;String view=openViews.remove(p.getUniqueId());if("backpack".equals(view)){data.set(path(p)+".backpack",e.getInventory().getContents());saveData();}}
    @EventHandler public void onJoin(PlayerJoinEvent e){Player p=e.getPlayer();if(!data.contains(path(p)+".money"))setBalance(p.getUniqueId(),getConfig().getDouble("settings.economy.starting-balance",1000));Bukkit.getScheduler().runTaskLater(this,()->updateBoard(p),10L);}
    @EventHandler public void onQuit(PlayerQuitEvent e){openViews.remove(e.getPlayer().getUniqueId());}
    @EventHandler public void onDeath(PlayerDeathEvent e){if(e.getEntity().getKiller()!=null){UUID k=e.getEntity().getKiller().getUniqueId();data.set("players."+k+".quest.kills",data.getLong("players."+k+".quest.kills",0)+1);data.set("players."+k+".kills",data.getLong("players."+k+".kills",0)+1);}UUID d=e.getEntity().getUniqueId();data.set("players."+d+".deaths",data.getLong("players."+d+".deaths",0)+1);saveData();}
    private void updateBoard(Player p){if(!getConfig().getBoolean("settings.scoreboard",true)||!p.isOnline())return;Scoreboard board=Bukkit.getScoreboardManager().getNewScoreboard();Objective obj=board.registerNewObjective("cherry",Criteria.DUMMY,Component.text("Cherry",NamedTextColor.LIGHT_PURPLE).append(Component.text("Essentials",NamedTextColor.YELLOW)));obj.setDisplaySlot(DisplaySlot.SIDEBAR);String rank=data.getString(path(p)+".rank","Member"),clan=data.getString(path(p)+".clan","None");long k=data.getLong(path(p)+".kills",0),d=data.getLong(path(p)+".deaths",0);String kd=d==0?String.format(Locale.US,"%.2f",(double)k):String.format(Locale.US,"%.2f",(double)k/d);String dim=switch(p.getWorld().getEnvironment()){case NORMAL->"Overworld";case NETHER->"Nether";case THE_END->"The End";default->p.getWorld().getName();};String[] lines={"§7PROFILES","§fNAME: §e"+p.getName(),"§fMONEY: §a"+String.format(Locale.US,"%.0f",balance(p.getUniqueId())),"§fCLAN: §d"+clan,"§fRANK: §e"+rank,"§8----------------","§7SERVER","§fONLINE: §a"+Bukkit.getOnlinePlayers().size(),"§fTPS: §a"+String.format(Locale.US,"%.1f",Bukkit.getTPS()[0]),"§fK/D: §b"+kd,"§fDIM: §d"+dim};int score=lines.length;for(String line:lines){String unique=line;while(board.getEntries().contains(unique))unique+="§r";obj.getScore(unique).setScore(score--);}p.setScoreboard(board);}
    @Override public List<String> onTabComplete(CommandSender s,Command c,String a,String[] args){if(args.length==1&&List.of("pay","tpa","rank").contains(c.getName()))return Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(n->n.toLowerCase().startsWith(args[0].toLowerCase())).toList();if(c.getName().equals("bank")&&args.length==1)return List.of("deposit","withdraw");if(c.getName().equals("clan")&&args.length==1)return List.of("create","leave");return List.of();}
}
